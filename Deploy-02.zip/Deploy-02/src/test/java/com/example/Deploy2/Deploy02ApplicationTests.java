package com.example.Deploy2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Deploy02ApplicationTests {

	@Test
	void contextLoads() {
	}

}
