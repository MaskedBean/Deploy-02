package com.example.Deploy2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Deploy02Application {

	public static void main(String[] args) {
		SpringApplication.run(Deploy02Application.class, args);
	}

}
